var i = 0;
var txt = "Hi, I'm Bert."; /* The text */
var speeds = [120, 120, 10, 300, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120]; /* The speed/duration of the effect in milliseconds */

function typeWriter() {
  if (i < txt.length) {
    document.getElementById("typer").innerHTML += txt.charAt(i);
    i++;
    setTimeout(typeWriter, speeds[i]);
  }
}

typeWriter()