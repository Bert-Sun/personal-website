var cur_descript = "cpp"

function go(slide){
    document.getElementById(cur_descript).style.display = "none"
    document.getElementById(cur_descript+"-btn").classList.remove("nav-button-active")
    cur_descript = slide
    document.getElementById(slide).style.display = "flex"
    document.getElementById(cur_descript+"-btn").classList.add("nav-button-active")
}

function set(link){
    window.location.href = link
}

// go('vba')